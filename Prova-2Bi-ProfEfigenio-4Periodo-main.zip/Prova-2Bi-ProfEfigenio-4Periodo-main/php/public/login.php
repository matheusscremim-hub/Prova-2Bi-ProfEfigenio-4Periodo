<?php
session_start();
require_once __DIR__ . '/controllers/AuthController.php';

$controller = new AuthController();
$controller->login();
